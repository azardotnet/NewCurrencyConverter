﻿using CurrencyConverter.Controllers;
using CurrencyConverter.Interface;
using CurrencyConverter.Utils;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CurrencyConverter.UnitTests
{
    public class CurrecyControllertTest
    {
        private readonly Mock<Microsoft.Extensions.Logging.ILogger<CurrencyController>> _loggerMock;
        private readonly Mock<ICurrencyRepository> _currencyRepositoryMock;
        private readonly Mock<IWebHostEnvironment> _hostEnvironment;
        public CurrecyControllertTest()
        {
            _loggerMock = new Mock<Microsoft.Extensions.Logging.ILogger<CurrencyController>>();
            _currencyRepositoryMock = new Mock<ICurrencyRepository>();
            _hostEnvironment = new Mock<IWebHostEnvironment>();
        }

        [Fact]
        public async Task GetCurrencyData_ReturnsOkObjectResult_WhenSuccessful()
        {
            // Arrange

            var controller = new CurrencyController(_loggerMock.Object, _currencyRepositoryMock.Object, _hostEnvironment.Object);
            string sourceCurrency = "USD";
            string? TargetCurrency = "INR";
            decimal Amount = 10;

            var expectedResponse = new ResponseMessage()
            {
                ConvertedAmount = 740,
                ExchangeRate =74,
                Message = "Success"
            };
            _currencyRepositoryMock.Setup(x => x.GetCurrencyData(sourceCurrency,TargetCurrency,Amount)).ReturnsAsync(expectedResponse);


            // Act
            var result = await controller.GetCurrencyData(sourceCurrency,TargetCurrency,Amount);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ResponseMessage>(okResult.Value);
            Assert.Equal(expectedResponse, actualResponse);
        }
    }



}