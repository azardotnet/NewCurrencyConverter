﻿using CurrencyConverter.Interface;
using CurrencyConverter.Utils;
using Microsoft.AspNetCore.Components.Web;
using Newtonsoft.Json;
using System.Dynamic;
using System.Formats.Asn1;
using System.Reflection;
using System.Text.Json;

namespace CurrencyConverter.Repositories
{
    public class CurrencyRepository : ICurrencyRepository
    {
        private readonly ILogger<CurrencyRepository> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public CurrencyRepository(ILogger<CurrencyRepository> logger, IWebHostEnvironment hostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = hostEnvironment;
        }   
        public async Task<ResponseMessage> GetCurrencyData(string sourceCurrency, string targetCurrency, decimal amount)
        {
            ResponseMessage _responseMessage = new ResponseMessage();
            string _message = string.Empty;
            try
            {
                var htmlFilePath = Path.Combine(_webHostEnvironment.WebRootPath, "exchangeRates.json");
                _logger.LogInformation("Repository: GetCurrency Method execution is Begin");               
                var isSourceCurrencyValid = AcceptCurrencies.Currencies.Any(a => a.Equals(sourceCurrency, StringComparison.OrdinalIgnoreCase));
                var isTargetCurrencyValid = AcceptCurrencies.Currencies.Any(a => a.Equals(targetCurrency, StringComparison.OrdinalIgnoreCase));

                if (!isSourceCurrencyValid)
                {
                    _logger.LogInformation("Source Currency type is Invalid");
                    _message = "Source Currency,";
                }
                if (!isTargetCurrencyValid)
                {
                    _logger.LogInformation("Target Currency type is Invalid");
                    _message += "Target Currency";
                }
                if (!isSourceCurrencyValid || !isTargetCurrencyValid)
                {
                    _responseMessage.Message = _message.TrimEnd(',') + " is invalid currency type";
                    return _responseMessage;
                }
                _responseMessage = GetCurrencyConvertedAmount(sourceCurrency, targetCurrency, amount);
                _responseMessage.ConvertedAmount = _responseMessage.ConvertedAmount;
                _responseMessage.ExchangeRate = _responseMessage.ExchangeRate;
                _logger.LogInformation("Repository: GetCurrency Method execution is end");
            }
            catch(Exception ex)
            {
               _responseMessage.Message = ex.Message;
                _logger.LogInformation($"Error: {ex.Message}");
            }
            return _responseMessage;
        }

        public ResponseMessage GetCurrencyConvertedAmount(string sourceCurrency, string targetCurrency, decimal amount)
        {
            ResponseMessage _responseMessage = new ResponseMessage();
            string _currencyType = string.Empty;
            decimal _exchangeRate = 0;
            decimal _convertedAmount = 0;
            ExchangeRateJson jsonObj = new ExchangeRateJson();
            
            try
            {
                if (_webHostEnvironment.IsEnvironment("Production"))
                {
                    SetJsonValues();
                }               
                var jsonFilePath = Path.Combine(_webHostEnvironment.WebRootPath, "exchangeRates.json");
                var serializer = new Newtonsoft.Json.JsonSerializer();
                using (var streamReader = new StreamReader(jsonFilePath)) {
                    using (var textReader = new JsonTextReader(streamReader))
                    {
                        var data = serializer.Deserialize<ExchangeRateJson>(textReader);
                        if (data == null)
                        {
                            return _responseMessage;
                        }
                        _currencyType = sourceCurrency + "_TO_" + targetCurrency;

                        #region CurrencyTypeChecks
                        if (_currencyType == nameof(jsonObj.EUR_TO_INR))
                        {
                            _exchangeRate = Convert.ToDecimal(data.EUR_TO_INR);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else if (_currencyType == nameof(jsonObj.EUR_TO_USD))
                        {
                            _exchangeRate = Convert.ToDecimal(data.EUR_TO_USD);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else if (_currencyType == nameof(jsonObj.USD_TO_INR))
                        {
                            _exchangeRate = Convert.ToDecimal(data.USD_TO_INR);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else if (_currencyType == nameof(jsonObj.USD_TO_EUR))
                        {
                            _exchangeRate = Convert.ToDecimal(data.USD_TO_EUR);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else if (_currencyType == nameof(jsonObj.INR_TO_EUR))
                        {
                            _exchangeRate = Convert.ToDecimal(data.INR_TO_EUR);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else if (_currencyType == nameof(jsonObj.INR_TO_USD))
                        {
                            _exchangeRate = Convert.ToDecimal(data.INR_TO_USD);
                            _convertedAmount = _exchangeRate * amount;
                        }
                        else
                        {

                        }
                        _responseMessage.ExchangeRate = _exchangeRate;
                        _responseMessage.ConvertedAmount = _convertedAmount;
                        #endregion
                       
                        streamReader.Close();
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.LogInformation("error occured in UseJsonTextReaderInNewtonsoftJson -" + ex.Message);

            }
            return _responseMessage;
        }

        public void SetJsonValues()
        {
            try
            {
                var jsonFilePath = Path.Combine(_webHostEnvironment.WebRootPath, "exchangeRates.json");
                var serializer = new Newtonsoft.Json.JsonSerializer();
                using (var streamReader = new StreamReader(jsonFilePath))
                {
                    using (var textReader = new JsonTextReader(streamReader))
                    {
                        var data = serializer.Deserialize<ExchangeRateJson>(textReader);
                        data.USD_TO_INR = "81.00";
                        string output = JsonConvert.SerializeObject(data, Formatting.Indented);
                        File.WriteAllText(jsonFilePath, output);
                    }
                }               
            }
            catch(Exception ex)
            {
                _logger.LogInformation("Exception on SetJsonValues - " + ex.Message);
            }
        }

    }
}
