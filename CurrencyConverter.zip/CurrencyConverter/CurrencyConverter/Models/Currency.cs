﻿namespace CurrencyConverter.Models
{
    public class Currency
    {
        public decimal ExchangeRate { get; set; }
        public decimal ConvertedAmount { get; set; }
    }
}
            