﻿using CurrencyConverter.Utils;

namespace CurrencyConverter.Interface
{
    public interface ICurrencyRepository
    {
        Task<ResponseMessage> GetCurrencyData(string sourceCurrency, string targetCurrency, decimal amount);
    }

}
