﻿namespace CurrencyConverter.Utils
{
    public class ExchangeRateJson
    {
        public string? USD_TO_INR { get; set; }
        public string? INR_TO_USD { get; set; }
        public string? USD_TO_EUR { get; set; }
        public string? EUR_TO_USD { get; set; }
        public string? INR_TO_EUR { get; set; }
        public string? EUR_TO_INR { get; set; }
    }
}
