﻿namespace CurrencyConverter.Utils
{
    public class ResponseMessage
    {
        public string? Message { get; set; }
        public decimal? ExchangeRate { get; set; }
        public decimal? ConvertedAmount { get; set;}

    }
}
