﻿namespace CurrencyConverter.Utils
{
    public static class AcceptCurrencies
    {
       public static string[]? Currencies = new[]
        {
        "INR", "USD", "EUR"
         };
    }
}
