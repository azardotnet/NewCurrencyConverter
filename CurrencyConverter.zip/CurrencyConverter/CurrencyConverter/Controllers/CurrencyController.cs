﻿using CurrencyConverter.Interface;
using CurrencyConverter.Utils;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace CurrencyConverter.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CurrencyController : ControllerBase
    {
        private readonly ILogger<CurrencyController> _logger;
        private readonly ICurrencyRepository _currencyService;
       // private readonly IWebHostEnvironment _hostingEnvironment;

        public CurrencyController(ILogger<CurrencyController> logger, ICurrencyRepository currencyService, IWebHostEnvironment hostingEnvironment)
        {

            _logger = logger;
            _currencyService = currencyService;
          //  _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet(Name = "GetCurrencyData")]
        public async Task<ActionResult<ResponseMessage>> GetCurrencyData(string sourceCurrency, string targetCurrency, decimal amount)
        {            
            _logger.LogInformation("GetCurrencyData is Started");
            try
            {
                var result = await _currencyService.GetCurrencyData(sourceCurrency, targetCurrency, amount);
                if (result != null)
                {
                    return new OkObjectResult(result);
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError("GetCurrencyData ||" + "Exception details-" + ex.Message, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

    }
}
