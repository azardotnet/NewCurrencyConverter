﻿using CurrencyConverter.Interface;
using CurrencyConverter.Repositories;
using System.Diagnostics.CodeAnalysis;

namespace ds.openblue.cep.servicemax.consumerapi.API.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class DependencyInjectionService
    {
        public static void ConfigureDependencyInjection(this IServiceCollection services)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            IConfiguration? configuration1 = services.BuildServiceProvider().GetService<IConfiguration>();
            IConfiguration? configuration = configuration1;
            #region Alternate Code for handling null reference
   
            #endregion
            services.AddLogging();            
            services.AddScoped<ICurrencyRepository,CurrencyRepository>();
            //services.Configure<AppsettingsConfig>(configuration?.GetSection("Okta"));
            //services.Configure<AppsettingsConfig>(configuration?.GetSection("Notification"));
            //services.Configure<AppsettingsConfig>(configuration?.GetSection("AutomationUser"));
            //services.AddDbContext<ConsumerContext>(options =>
            //{
            //    options.UseSqlServer(configuration?.GetConnectionString("Connections"));

            //}, ServiceLifetime.Transient);
        }
    }
}
